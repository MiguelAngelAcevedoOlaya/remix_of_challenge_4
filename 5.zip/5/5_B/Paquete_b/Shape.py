class Point:
    # Definition of the Point class
    definition: str = "Abstract geometric entity that represents a location in space."

    # Constructor method for the Point class
    def __init__(self, x: float = 0, y: float = 0):
        self.x = x
        self.y = y

    # Method to move the point to a new location
    def move(self, new_x: float, new_y: float):
        self.x = new_x
        self.y = new_y

    # Method to reset the point to the origin
    def reset(self):
        self.x = 0
        self.y = 0
    
    # Method to calcule the distance of two points
    def compute_distance(self, point)-> float:
        distance = (((self.x - point.x)**2) + ((self.y - point.y)**2))**(0.5)
        return distance

class Line:
    # Constructor method to initialize the Line object with start and end points
    def __init__(self, start, end):
        self.start = start  # Start point of the line
        self.end = end      # End point of the line
        self.length = start.compute_distance(end)
        
class Shape: # Super class
    def __init__(self, regular: bool, vertices: list, edges: list, inner_angles: list):
        self.regular = regular # The form is regular?
        self.vertices = vertices # Vertices of the form
        self.edges = edges  # Calculate the length of the points
        self.inner_angles = inner_angles # Angles
    
    def compute_area(self): # Funtion to calcule the area
        pass
    
    def compute_perimeter(self): # Funtion to calculate the perimeter
        pass
    
    def compute_inner_angles(self): # Funtion to calculate angles
        pass