from .Triangle import Triangle # Import equilateral

class Equilateral(Triangle): # Class herence
    def __init__(self, regular:bool, vertices:list, edges:list, inner_angles:list):
        super().__init__(regular, vertices, edges, inner_angles)
        
    def is_equilateral(self): # We need to see if is a equilateral, it is if all the lines are equal
        if self.edges[0] == self.edges[1] and self.edges[1] == self.edges[2]:
            return True
        else: return False
    
    def compute_perimeter(self):
        return super().compute_perimeter() # Call perimeter from triangle

    
    def compute_area(self):
        return super().compute_area() # Call area from triangle
    
    def compute_inner_angles(self):
        return super().compute_inner_angles() # Call inner angles from triangle
