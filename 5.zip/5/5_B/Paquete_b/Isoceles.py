from .Triangle import Triangle

class Isoceles(Triangle): # Class Herence
    def __init__(self, regular:bool, vertices:list, edges:list, inner_angles:list):
        super().__init__(regular, vertices, edges, inner_angles)
        
    def is_isoceles(self): # Define if is a isoceles, 2 lines need to be equal
        if self.edges[0] == self.edges[1] or self.edges[0] == self.edges[2] or self.edges[1] == self.edges[2]:
            return True
        else: return False
    
    def compute_perimeter(self):
        return super().compute_perimeter() # Call perimeter in traingle
    
    def compute_area(self):
            return super().compute_area() # Call area in trinagle
    
    def compute_inner_angles(self): # Call inner angles in triangle
        return super().compute_inner_angles()
