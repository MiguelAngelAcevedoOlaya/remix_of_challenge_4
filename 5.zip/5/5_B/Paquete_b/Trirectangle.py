from .Triangle import Triangle

class Trirectangle(Triangle): #Class herence
    def __init__(self, regular:bool, vertices:list, edges:list, inner_angles:list):
        super().__init__(regular, vertices, edges, inner_angles)

    def is_trirectangle(self): # We need to si if a rectnagle triangle, we considere a few calculate mistake that happens in python
        super().compute_inner_angles()
        for i in self.inner_angles:
            if abs(i - 90) < 0.1:
                return True
        else: return False
            
    def compute_perimeter(self):
        return super().compute_perimeter() # call perimeter from triangle
    
    def compute_area(self): # call area from triangle
        return super().compute_area()
    
    def compute_inner_angles(self): # call inner angles from triangle
        return super().compute_inner_angles()
  