import math

from .Shape import Shape

class Triangle(Shape): # Class
    def __init__(self, regular:bool, vertices:list, edges:list, inner_angles:list):
        super().__init__(regular, vertices, edges, inner_angles)
        self.compute_perimeter() # Call perimeter 
    
    def compute_perimeter(self):
        if len(self.edges) == 3: # Len of vertices need to be three
            perimeter = self.edges[0] + self.edges[1] + self.edges[2]
            self.perimeter = perimeter
            return perimeter # Return the perimeter
        pass

    def compute_area(self):
        if len(self.edges) == 3:
            s_heron = self.perimeter / 2 # I use the heron formula to calculate the area because it´s funtion for all triangles
            area = (s_heron*(s_heron-self.edges[0])*(s_heron-self.edges[1])*(s_heron-self.edges[2]))**0.5
            return area
        else:
            pass
    
    def compute_inner_angles(self):
        if len(self.edges) == 3: # We use arcoseno to calculate the angles of the traingle, this funtion in all triangles
            angle_a = math.degrees(math.acos((self.edges[1]**2 + self.edges[2]**2 - self.edges[0]**2) / (2 * self.edges[1] * self.edges[2])))
            angle_b = math.degrees(math.acos((self.edges[2]**2 + self.edges[0]**2 - self.edges[1]**2) / (2 * self.edges[0] * self.edges[2])))
            angle_c = math.degrees(math.acos((self.edges[0]**2 + self.edges[1]**2 - self.edges[2]**2) / (2 * self.edges[0] * self.edges[1])))
            self.inner_angles = [angle_a, angle_b, angle_c]
            return self.inner_angles
        else: pass