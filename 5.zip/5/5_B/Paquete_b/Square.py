from .Rectangle import Rectangle

class Square(Rectangle): # Class Herence
    def __init__(self, regular:bool, vertices:list, edges:list, inner_angles:list):
        super().__init__(regular, vertices, edges, inner_angles)
    
    def is_square(self):
        super().is_rectangle() # Prove if is a rectangle but why?
        if Rectangle.is_rectangle() == True:
            if self.height == self.width: # To call this things and see if they are equal, in case that not, it´s not a square
                return True # Is square
            else:
                return False # Is´nt an square
        else:
            return False
        
    def compute_perimeter(self):
        return super().compute_perimeter() # Call perimeter from rectangle

    
    def compute_area(self):
        return super().compute_area() # Call area from rectangle
    
    def compute_inner_angles(self):
        return super().compute_inner_angles() # Call inner angles from rectangle
  