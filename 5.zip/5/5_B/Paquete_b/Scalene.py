from .Triangle import Triangle

class Scalene(Triangle): # Class herence
    def __init__(self, regular:bool, vertices:list, edges:list, inner_angles:list):
        super().__init__(regular, vertices, edges, inner_angles)
        
    def is_scalene(self): # We need to si if is scalen, the three lines are diferente
        if self.edges[0] != self.edges[1] and self.edges[0] != self.edges[2] and self.edges[1] != self.edges[2]:
            return True
        else: return False
    
    def compute_perimeter(self): # Call perimeter from triangle
        return super().compute_perimeter()
    
    def compute_area(self):
        return super().compute_area() # Call area from tringle

    
    def compute_inner_angles(self):
        return super().compute_inner_angles() # Call inner angles from triangle
