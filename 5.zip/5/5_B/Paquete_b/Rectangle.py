import math

from .Shape import Shape

class Rectangle(Shape): # Class 
    def __init__(self, regular:bool, vertices:list, edges:list, inner_angles:list):
        super().__init__(regular, vertices, edges, inner_angles)
        self.is_rectangle()
    
    def is_rectangle(self): # Try to see if the points that the user enter make a rectangle
        if len(self.edges) == 4:
            sorted_vertices = sorted(self.vertices, key=lambda point: point.x) # Order the points
            if sorted_vertices[0].x == sorted_vertices[1].x:
                if sorted_vertices[2].x == sorted_vertices[3].x:
                    if sorted_vertices[0].y == sorted_vertices[2].y:
                        if sorted_vertices[1].y == sorted_vertices[3].y: # If they are a rectangle
                            width = self.vertices[2].x - self.vertices[0].x # Calculate the width
                            height = self.vertices[1].y - self.vertices[0].y # Calculate the height
                            self.width = width
                            self.height = height
                            return True
                        else: 
                            return False # In all other cases the form is not a rectangle, and base of that we don´t need to do the other
                    else: 
                        return False
                else:
                    return False
            else: 
                return False
        else:
            return False
            
    def compute_perimeter(self):
        if len(self.edges) == 4:
            perimeter = (2*self.width + 2*self.height) # Calculate perimeter in base of with and height
            return perimeter
        else:
            pass

    def compute_area(self):
        if len(self.edges) == 4:
            area = self.height * self.width # Caclulate the area of a form with 4 lines
            return area
        else:
            pass
    
    def compute_inner_angles(self):
        if len(self.edges) == 4:
            self.inner_angles = [90, 90, 90, 90] # If is a rectangle, you don´t need to calculate angles, there are 90 
            return self.inner_angles
        else: pass
