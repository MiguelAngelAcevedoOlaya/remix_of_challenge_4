from Paquete.reto_4 import Point # Import point
from Paquete.reto_4 import Line # Import line
from Paquete.reto_4 import Rectangle # Import rectangle
from Paquete.reto_4 import Isoceles # Import isoceles
from Paquete.reto_4 import Equilateral # Import equilateral
from Paquete.reto_4 import Scalene # Import scalene
from Paquete.reto_4 import Trirectangle # Import trirectangle
from Paquete.reto_4 import Square # Import square

if __name__ == "__main__":
    # Ask the user whether they want to input 3 or 4 points
    figure = int(input("You want to enter 3 or 4 points: "))
    flag = True

    # Validate the user input
    while flag == True:
        if figure == 3 or figure == 4:
            break
        else:
            figure = int(input("You want to enter 3 or 4 points: "))

    # Process based on the number of points entered by the user
    if figure == 3:
        # Obtain the coordinates of three points from the user
        p1 = Point(int(input("Enter the x coordinate of the p1: ")), int(input("Enter the y coordinate of the p1: ")))
        p2 = Point(int(input("Enter the x coordinate of the p2: ")), int(input("Enter the y coordinate of the p2: ")))
        p3 = Point(int(input("Enter the x coordinate of the p3: ")), int(input("Enter the y coordinate of the p3: ")))

        # Create lines using the provided points
        line1 = Line(p1, p2)
        line2 = Line(p2, p3)
        line3 = Line(p3, p1)

        # Create instances of different types of triangles
        triangulo = Isoceles(True, [p1, p2, p3], [line1.length, line2.length, line3.length], [0, 0, 0])
        triangulo_1 = Equilateral(True, [p1, p2, p3], [line1.length, line2.length, line3.length], [0, 0, 0])
        triangulo_2 = Scalene(True, [p1, p2, p3], [line1.length, line2.length, line3.length], [0, 0, 0])
        triangulo_3 = Trirectangle(True, [p1, p2, p3], [line1.length, line2.length, line3.length], [0, 0, 0])

        # Determine the type of triangle and perform calculations accordingly
        if triangulo.is_isoceles() == True:
            if triangulo_3.is_trirectangle() == True:
                print("The triangle is an isoceles and a rectangle triangle")
                per_trin = triangulo.compute_perimeter()
                print("The perimeter of the triangle is: " + str(per_trin))
                area_trin = triangulo.compute_area()
                print("The area of the triangle is: " + str(area_trin))
                angles_trin = triangulo.compute_inner_angles()
                print("The inner angles of the triangle is: " + str(angles_trin))
            else:
                print("The triangle is an isoceles")
                per_trin = triangulo.compute_perimeter()
                print("The perimeter of the triangle is: " + str(per_trin))
                area_trin = triangulo.compute_area()
                print("The area of the triangle is: " + str(area_trin))
                angles_trin = triangulo.compute_inner_angles()
                print("The inner angles of the triangle is: " + str(angles_trin))

        elif triangulo_1.is_equilateral() == True:
            print("The triangle is an Equilateral")
            per_trin = triangulo_1.compute_perimeter()
            print("The perimeter of the triangle is: " + str(per_trin))
            area_trin = triangulo_1.compute_area()
            print("The area of the triangle is: " + str(area_trin))
            angles_trin = triangulo_1.compute_inner_angles()
            print("The inner angles of the triangle is: " + str(angles_trin))

        elif triangulo_2.is_scalene() == True:
            if triangulo_3.is_trirectangle() == True:
                print("The triangle is an Scalene and a rectangle triangle")
                per_trin = triangulo_2.compute_perimeter()
                print("The perimeter of the triangle is: " + str(per_trin))
                area_trin = triangulo_2.compute_area()
                print("The area of the triangle is: " + str(area_trin))
                angles_trin = triangulo_2.compute_inner_angles()
                print("The inner angles of the triangle is: " + str(angles_trin))
            else: 
                print("The triangle is an Scalene")
                per_trin = triangulo_2.compute_perimeter()
                print("The perimeter of the triangle is: " + str(per_trin))
                area_trin = triangulo_2.compute_area()
                print("The area of the triangle is: " + str(area_trin))
                angles_trin = triangulo_2.compute_inner_angles()
                print("The inner angles of the triangle is: " + str(angles_trin))

    if figure == 4:
        # Obtain the coordinates of four points from the user
        p1 = Point(int(input("Enter the x coordinate of the p1: ")), int(input("Enter the y coordinate of the p1: ")))
        p2 = Point(int(input("Enter the x coordinate of the p2: ")), int(input("Enter the y coordinate of the p2: ")))
        p3 = Point(int(input("Enter the x coordinate of the p3: ")), int(input("Enter the y coordinate of the p3: ")))
        p4 = Point(int(input("Enter the x coordinate of the p4: ")), int(input("Enter the y coordinate of the p4: ")))

        # Sort the points based on their x-coordinate
        listi = [p1, p2, p3, p4]
        listi = sorted(listi, key=lambda p: (p.x, p.y))

        # Create lines using the provided points
        line1 = Line(listi[0], listi[1])
        line2 = Line(listi[0], listi[2])
        line3 = Line(listi[1], listi[3])
        line4 = Line(listi[2], listi[3])
        # Create instances of Rectangle and Square
        rectangulo = Rectangle(True, [listi[0], listi[1], listi[2], listi[3]], [line1.length, line2.length, line3.length, line4.length], [0, 0, 0, 0])
        cuadrado = Square(True, [listi[0], listi[1], listi[2], listi[3]], [line1.length, line2.length, line3.length, line4.length], [0, 0, 0, 0])

        # Check if the figure is a square or a rectangle
        if cuadrado.is_square() == True: # If it's a square
            print("The form is a square")
            per_cua = cuadrado.compute_perimeter() # Compute the perimeter
            print("The perimeter of the square is: " +str(per_cua))
            area_cua = cuadrado.compute_area() # Compute the area
            print("The area of the square is: " +str(area_cua))
            angles_cua = cuadrado.compute_inner_angles() # Compute the inner angles
            print("The inner angles of the square is: " +str(angles_cua))

        elif rectangulo.is_rectangle() == True: # If it's a rectangle
            print("The form is a Rectangle")
            per_rect = rectangulo.compute_perimeter() # Compute the perimeter
            print("The perimeter of the rectangle is: " +str(per_rect))
            area_rect = rectangulo.compute_area() # Compute the area
            print("The area of the rectangle is: " +str(area_rect))
            angles_rect = rectangulo.compute_inner_angles() # Compute the inner angles
            print("The inner angles of the rectangle is: " +str(angles_rect))
